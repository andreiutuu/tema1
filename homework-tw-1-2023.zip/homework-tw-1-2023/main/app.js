const compress = (a, b = true) => {
	if (typeof a !== 'string' && !(a instanceof String)) {
		throw new Error('InvalidType');
	}

	if (a.length === 0){
		return '';
	}
	
	if (b === true){
		let encoded = '';
		let currentChar = a[0];
		let count = 1;

		for (let i = 1; i < a.length; i++) {
			if (a[i] === currentChar) {
				count++;
			} else {
				encoded += currentChar + count;
				currentChar = a[i];
				count = 1;
			}
		}

		encoded += currentChar + count;

		return encoded;
	}
	else {

		let decoded = '';
		let i = 0;

		while (i < a.length) {
			let char = a[i];
			i++;
			let count = '';

			while (i < a.length && /\d/.test(a[i])) {
			count += a[i];
			i++;
			}

			count = parseInt(count, 10);
			decoded += char.repeat(count);
		}

		return decoded;
	}

}

module.exports = compress